<?php

$lang_fancy_image = array(
	'Original'		=> 'Original',
);
